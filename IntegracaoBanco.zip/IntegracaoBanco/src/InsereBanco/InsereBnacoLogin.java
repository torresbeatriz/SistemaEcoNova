package InsereBanco;
import java.sql.Connection;
import java.util.Scanner;

import ConectaComBanco.ConectaBancoLogin;

public class InsereBnacoLogin {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		
		String banco = "Banco";
		
		String usuario = "root";
		

		String senha = "admin";
		
		System.out.println("----Conectando Java e MySQL----");
		
		try {
			Connection conn = ConectaBancoLogin.getConnection(banco, usuario, senha);
			System.out.println("Conectou :)");
			
			System.out.println("Nome: ");
			String nome = entrada.nextLine();
			
			System.out.println("Email: ");
			String email = entrada.nextLine();
			
			System.out.println("Senha: ");
			String password = entrada.nextLine();
			
			
			String sql = String.format("insert into Banco.usuarios(email, senha, nome)" + 
			"values ('%s','%s','%s');", email, password,nome);
			
			entrada.close();
			
			ConectaBancoLogin.insert(conn, sql);
			
			for(String linha: ConectaBancoLogin.list(conn, "select id_usuario, nome, email from Banco.usuarios")) {
				System.out.println(linha);
			}
			
		}catch (Exception e){
			System.out.println("Não conectou :(");
			e.printStackTrace();
		}
		
		

	}

}
