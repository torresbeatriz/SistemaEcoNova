package InsereBanco;
import java.sql.Connection;

import java.util.Scanner;

import ConectaComBanco.ConectaBancoQuantia;

public class InsereBancoQuantia {
	
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		
		String banco = "Banco";
		
		String usuario = "root";
		

		String senha = "admin";
		
		System.out.println("----Conectando Java e MySQL----");
		
		try {
			Connection conn = ConectaBancoQuantia.getConnection(banco, usuario, senha);
			System.out.println("Conectou :)");
			
			System.out.println("Para informar a quantidade de carbono compensado, preencha as informações solicitadas");
			
			System.out.println("ID da empresa: ");
			String empresa = entrada.nextLine();
			
			System.out.println("Quantidade Compensada: ");
			String quantidade = entrada.nextLine();
			
			
			String sql = String.format("insert into Banco.carbono(id_usuario, carbono_compensado)" + 
			"values ('%s','%s');", empresa, quantidade);
			entrada.close();
			
			ConectaBancoQuantia.insert(conn, sql);
			
			for(String linha: ConectaBancoQuantia.list(conn, "select usuarios.nome, carbono.carbono_compensado from Banco.usuarios, Banco.carbono")) {
				System.out.println(linha);
			}
			
		}catch (Exception e){
			System.out.println("Não conectou :(");
			e.printStackTrace();
		}
		
		

	}

}



